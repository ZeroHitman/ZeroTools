cmd_/app/Module.symvers := sed 's/ko$$/o/' /app/modules.order | scripts/mod/modpost -m    -o /app/Module.symvers -e -i Module.symvers   -T -
