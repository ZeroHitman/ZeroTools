#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd5bf83c7, "module_layout" },
	{ 0xf2bd6d37, "try_module_get" },
	{ 0x37a0cba, "kfree" },
	{ 0x1e6d26a8, "strstr" },
	{ 0xe12fe575, "access_process_vm" },
	{ 0x93dca106, "kmem_cache_alloc_trace" },
	{ 0x79dae111, "kmalloc_caches" },
	{ 0x78f310f, "current_task" },
	{ 0xf6c42b, "unregister_ftrace_function" },
	{ 0xc5850110, "printk" },
	{ 0x66b94470, "register_ftrace_function" },
	{ 0x2fdce7c0, "ftrace_set_filter_ip" },
	{ 0xafd744c6, "__x86_indirect_thunk_rbp" },
	{ 0x108be812, "unregister_kprobe" },
	{ 0xe73fe9c, "register_kprobe" },
	{ 0xbad7760e, "commit_creds" },
	{ 0xcf023579, "prepare_creds" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
};

MODULE_INFO(depends, "");

