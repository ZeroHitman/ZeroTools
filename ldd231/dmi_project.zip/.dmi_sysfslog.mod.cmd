cmd_/app/dmi_sysfslog.mod := { echo  /app/dmi_sysfslog.o;  echo; } > /app/dmi_sysfslog.mod
