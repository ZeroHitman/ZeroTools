/app/dmi_sysfslog.o

