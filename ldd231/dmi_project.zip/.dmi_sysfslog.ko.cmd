cmd_/app/dmi_sysfslog.ko := ld -r -m elf_x86_64 -z noexecstack --build-id=sha1  -T arch/x86/module.lds -o /app/dmi_sysfslog.ko /app/dmi_sysfslog.o /app/dmi_sysfslog.mod.o;  true
