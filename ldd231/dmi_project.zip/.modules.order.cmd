cmd_/app/modules.order := {   echo /app/dmi_sysfslog.ko; :; } | awk '!x[$$0]++' - > /app/modules.order
